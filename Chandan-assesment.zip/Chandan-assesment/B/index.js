function loadDataFromAPI() {
  fetch("https://api.publicapis.org/entries?category=animals")
    .then(res => res.json())
    .then(response => {
      const ul = document.getElementById("links-ul");
      response.entries.forEach(ele => {
        const li = document.createElement("li");
        const aLink = document.createElement("a");
        aLink.setAttribute("href", ele.Link);
        aLink.text = ele.API;
        li.appendChild(aLink);
        ul.appendChild(li);
      });
    });
}
