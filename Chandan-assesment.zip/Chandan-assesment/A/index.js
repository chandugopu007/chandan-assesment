const mockData = [
  {
    firstName: "Reinwald",
    lastName: "Pranger",
    subjects: ["Math"]
  },
  {
    firstName: "Mill",
    lastName: "Smaridge",
    subjects: ["English"]
  },
  {
    firstName: "Bourke",
    lastName: "Ikin",
    subjects: ["Science"]
  },
  {
    firstName: "Wainwright",
    lastName: "Barsby",
    subjects: ["Reading"]
  },
  {
    firstName: "Franni",
    lastName: "Monnery",
    subjects: ["Math, English"]
  },
  {
    firstName: "Grete",
    lastName: "Woolfall",
    subjects: ["Science, Reading"]
  },
  {
    firstName: "Melody",
    lastName: "Maddinon",
    subjects: ["Math, Reading"]
  },
  {
    firstName: "Kiersten",
    lastName: "Crosskill",
    subjects: ["Science, English"]
  },
  {
    firstName: "Dannel",
    lastName: "Peppard",
    subjects: ["Math, Science, Reading"]
  },
  {
    firstName: "Tadeo",
    lastName: "Snaddon",
    subjects: ["Reading, Science, Math, English"]
  }
];

function loadData() {
  const tableBody = document.getElementById("student-info-body");
  mockData.forEach(ele => {
    const tr = document.createElement("tr");
    const firstName = document.createElement("td");
    firstName.appendChild(document.createTextNode(ele.firstName));
    const lastName = document.createElement("td");
    lastName.appendChild(document.createTextNode(ele.lastName));
    const subjects = document.createElement("td");
    subjects.appendChild(document.createTextNode(ele.subjects));
    tr.appendChild(firstName);
    tr.appendChild(lastName);
    tr.appendChild(subjects);
    tableBody.appendChild(tr);
  });
}
