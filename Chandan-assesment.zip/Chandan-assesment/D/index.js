let minutes = 0;
let seconds = 0;
let timerInterval = 0;

function stop() {
  clearInterval(timerInterval);
}

function start() {
  timerInterval = setInterval(updateStopWatch, 1000);
}

function reset() {
  clearInterval(timerInterval);
  minutes = 0;
  seconds = 0;
  setStopWatch(0, 0);
}

function updateStopWatch() {
  seconds++;
  if (seconds >= 60) {
    seconds = 0;
    minutes++;
  }

  setStopWatch(minutes, seconds);
}

function setStopWatch(minutes, seconds) {
  const mins = document.getElementById("minutes");
  const secs = document.getElementById("seconds");
  mins.textContent = minutes ? (minutes > 9 ? minutes : "0" + minutes) : "00";
  secs.textContent = seconds > 9 ? seconds : "0" + seconds;
}
